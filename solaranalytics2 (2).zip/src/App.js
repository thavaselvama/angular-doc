import React from 'react';
import {ThemeProvider } from '@mui/material/styles';
import {theme} from './Theme/theme';
import {CssBaseline, StyledEngineProvider } from '@mui/material';
import './assets/scss/app.scss';

// routing
import AppRoutes from './Routes/index';


function App() {
  return (
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={theme()}>
        <CssBaseline />
        <div className="App">      
            <AppRoutes />
        </div>
      </ThemeProvider>
    </StyledEngineProvider>
  );
}

export default App;
