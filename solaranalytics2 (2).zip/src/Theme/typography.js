export default function typography(theme) {
    return {
        fontFamily: `'Roboto', sans-serif`,           
        fontSize : "0.875 rem",
        fontWeightLight : 300,
        fontWeightRegular : 400,
        fontWeightMedium : 500   
    };
}
