export const drawerWidth = 250;
export const gridSpacing = 3;