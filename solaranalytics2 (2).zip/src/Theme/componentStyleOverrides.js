export default function componentStyleOverrides(theme) {    
  return {
    MuiButtonBase: {
      defaultProps: {
        disableRipple: true,
      },
    },
    MuiListItemButton: {
      styleOverrides: {
        root: {
          color: theme.darkTextPrimary,
          paddingTop: "5px",
          paddingBottom: "5px",
          "&.Mui-selected": {
            color: theme.palette.text.light,
            backgroundColor: theme.palette.primary.main,            
            "&:hover": {
              backgroundColor: theme.palette.primary.main,
            },
            "& .MuiListItemIcon-root": {
              color: theme.palette.text.light,
            },
          },
          "&:hover": {
            backgroundColor: theme.palette.primary.main,
            color: theme.palette.text.light,
            "& .MuiListItemIcon-root": {
              color: theme.palette.text.light,
            },
          },
        },
      },
    },
  };
}
