export default function defaultStyles(theme) {
    return {        
        borderRadius: 12     
    };
}
