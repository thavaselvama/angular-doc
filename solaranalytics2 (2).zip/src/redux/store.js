import { configureStore } from '@reduxjs/toolkit';
import appReducer from '../redux/reducer/app/appSlice';

export const store = configureStore({
  reducer: {
    appReducer,
  },
});
