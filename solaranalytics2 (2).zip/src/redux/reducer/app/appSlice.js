import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  leftDrawerOpened: false,  
};

export const appSlice = createSlice({
  name: 'appReducer',
  initialState,  
  reducers: {
    toggleLeftDrawer: (state) => {            
      state.leftDrawerOpened = !state.leftDrawerOpened;
    }
  },
});

export const { toggleLeftDrawer} = appSlice.actions;

export default appSlice.reducer;
