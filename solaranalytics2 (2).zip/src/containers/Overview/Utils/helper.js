export const fakeData = {
  cardData: [
    {
      title: "Total Panel",
      icon: "solar",
      itemList: [
        {
          value: "8",
          label: "Active",
        },
        {
          value: "1",
          label: "Deactivate",
        },
      ],
    },
    {
      title: "Daily Energy",
      icon: "thunder",
      itemList: [
        {
          value: "123.75",
          suffix: "kWh",
        },
      ],
      helperText: "Past 1 day",
    },
    {
      title: "Monthly Energy",
      icon: "thunder",
      itemList: [
        {
          value: "134.75",
          suffix: "kWh",
        },
      ],
      helperText: "Past 1 month",
    },
    {
      title: "Total Revenue",
      icon: "dollar",
      itemList: [
        {
          value: "2456.76",
        },
      ],
      helperText: "Past 1 month",
    },
  ],

  emissionDoughnutChart: {
    labels: ["Saved", "Used"],
    datasets: [
      {
        data: [80, 20],
        backgroundColor: ["#df614d", "#eeeeee"],
        borderColor: "#d1d1d1",
        borderWidth: 1,
      },
    ],
  },
  plantDoughnutChart: {
    labels: ["Planted", "Unplanted"],
    datasets: [
      {
        data: [12, 80],
        backgroundColor: ["#66c437", "#eeeeee"],
        borderColor: "#d1d1d1",
        borderWidth: 1,
      },
    ],
  },

  panelEnergyHorizontalBarChart: {
    labels: [
      "Panel 1",
      "Panel 2",
      "Panel 3",
      "Panel 4",
      "Panel 5",
      "Panel 6",
      "Panel 7",
    ],
    datasets: [
      {
        label: "My First dataset",
        backgroundColor: [
          "#67dc98",
          "#7ddd67",
          "#c4dd67",
          "#dc67ce",
          "#a367dc",
          "#a0dd68",
          "#67dd76",
        ],
        borderWidth: 0,
        data: [96, 89, 72, 65, 58, 53, 43.45],
        datalabels: {
          color: "#000",
          anchor: "end",
          align: "start",
          weight: "bold",
          offset: "10",
        },
        borderRadius: 4,
      },
    ],
  },
};
