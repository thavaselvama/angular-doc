import React from 'react';
import {Bar} from 'react-chartjs-2';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import {horizontalChartOptions} from './helper';

const PanelEnergyHorizontalChart = (props) => {
    const {data} = props;
    return (
        <div className="chart-block">
            <div className="horizontal-bar-chart-wrapper">
                <Bar
                    data={data}
                    options = {horizontalChartOptions}
                    plugins={[ChartDataLabels]}
                />
            </div>
        </div>
    );
}

export default PanelEnergyHorizontalChart;