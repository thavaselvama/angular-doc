export const horizontalChartOptions = {
  indexAxis: "y",
  elements: {
    bar: {
      borderWidth: 1,
    },
  },
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: false,
    title: false,
    datalabels: {
      formatter: function (value, context) {
        return value + " kw";
      },
      anchor: "end",
      offset: 20,
    },
    tooltip: false,
  },
  scales: {
    y: {
      display: true,
      grid: {
        display: false,
      },
    },
    x: {
      ticks: {
        callback: function (value, index, values) {
          if (index) {
            return value + " kw";
          } else {
            return value;
          }
        },
      },
    },
  },
};
