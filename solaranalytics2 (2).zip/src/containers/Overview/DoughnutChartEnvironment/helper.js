export const doughnutOptions = {
  circumference: 180,
  rotation: -90,
  cutout : "60%",
  responsive: true,
  maintainAspectRatio : false,
  plugins: {
    legend: {
      display: false,
    },
    title: {
      display: false
    },
    tooltip: true,
  },
};
