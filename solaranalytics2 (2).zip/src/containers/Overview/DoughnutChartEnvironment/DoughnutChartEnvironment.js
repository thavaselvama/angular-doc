import { Doughnut } from 'react-chartjs-2';
import {doughnutOptions} from './helper';

const DoughnutChartEnvironment = (props) => {
    const {config, data} = props;
    let doughnutOptionsData = {
        ...doughnutOptions,        
    }
    return (
        <div className="chart-block">
            {config.icon && <div className={`icons ${config.icon}`}></div>}        
            <div className="doughnut-chart-wrapper">                
                <Doughnut          
                    data={data} 
                    options={ doughnutOptionsData}
                />            
            </div>
            <div className="value">{config.value}<span className="prefix">{config.prefix}</span></div>
            <div className="title">{config.title}</div>
        </div>
    );
}

export default DoughnutChartEnvironment;