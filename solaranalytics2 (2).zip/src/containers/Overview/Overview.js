import React, { useState } from "react";
import { useSelector } from "react-redux";

import { Grid, Box, useMediaQuery } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { gridSpacing } from "../../Theme/constants/constants";

import {
  DoughnutChartEnvironment,
  PanelEnergyHoziontalBarChart,
  PanelTable,
} from "./index";
import { AutoComplete, EnergyCard } from "../../components/index";
import { fakeData } from "./Utils/helper";
import { optionList } from "../../Utils/constants";
import "./Overview.scss";

function Overview(props) {
  const [panelEnergyFrequency, setPanelEnergyFrequency] = useState(
    optionList.frequency[0]
  );

  const theme = useTheme();
  const leftDrawerOpened = useSelector(
    (state) => state.appReducer.leftDrawerOpened
  );
  const matchUpLg = useMediaQuery(theme.breakpoints.up("lg"));

  return (
    <div className="overview-page">
      <Grid container spacing={gridSpacing}>
        <Grid item xs={12}>
          <Grid
            container
            spacing={gridSpacing}
            sx={{ marginTop: matchUpLg ? "20px" : "" }}
          >
            {fakeData.cardData.map((item, i) => {
              return (
                <Grid item xl={3} lg={3} sm={6} xs={12} key={item.id}>
                  <EnergyCard
                    {...item}
                    itemIndex={i}
                    total={fakeData.cardData.length}
                    matchUpLg={matchUpLg}
                    leftDrawerOpened={leftDrawerOpened}
                  />
                </Grid>
              );
            })}
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Grid container spacing={gridSpacing}>
            <Grid item xs={12} lg={6}>
              <div className="card-wrapper-default environment-card-wrapper">
                <div className="card-title-header">
                  <h2 className="title">Environment benefits</h2>
                </div>
                <Box className="doughnut-chart-environment-wrapper">
                  <DoughnutChartEnvironment
                    config={{
                      icon: "factory",
                      title: "CO2 Emmission saved",
                      value: "131.09",
                      prefix: "kg",
                    }}
                    data={fakeData.emissionDoughnutChart}
                  />
                  <DoughnutChartEnvironment
                    config={{
                      icon: "plant",
                      title: "Equivalent Trees Planted",
                      value: "212.45",
                    }}
                    data={fakeData.plantDoughnutChart}
                  />
                </Box>
              </div>
            </Grid>
            <Grid item xs={12} lg={6}>
              <div className="card-wrapper-default environment-card-wrapper">
                <div className="card-title-header">
                  <h2 className="title">Panel Energy</h2>
                  <div>
                    <AutoComplete
                      id={"panelEnergyWeekRange"}
                      options={optionList.frequency}
                      placeholder={"Select"}
                      disableClearable={true}
                      controlled={true}
                      value={panelEnergyFrequency}
                      onChange={(e, value) => setPanelEnergyFrequency(value)}
                      sx={{ width: 160 }}
                    />
                  </div>
                </div>
                <div className="horizontal-bar-chart-panel-energy-wrapper ">
                  <PanelEnergyHoziontalBarChart
                    data={fakeData.panelEnergyHorizontalBarChart}
                  />
                </div>
              </div>
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Grid container spacing={gridSpacing}>
            <Grid item xs={12} lg={12}>
              <div className="card-wrapper-default panel-table-wrapper">
                <div className="card-title-header">
                  <p className="title">Panel Info</p>
                </div>
                <PanelTable />
              </div>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
}

export default Overview;
