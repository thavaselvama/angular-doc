export const tableConfigOptions = (data) => {
  return {
    search: false,
    download: false,
    print: false,
    viewColumns: false,
    filter: false,
    // filterType: "dropdown",
    responsive: true,
    tableBodyHeight: true,
    tableBodyMaxHeight: true,
    onTableChange: (action, state) => {
      //   console.log(action);
      //   console.dir(state);
    },
  };
};

export const columnOptions = (data) => {
  const columns = [
    {
      name: "panel",
      label: "Panel",
      options: {
        filter: true,
        sort: true,
      },
    },
    {
      name: "location",
      label: "Location",
      options: {
        filter: true,
        sort: false,
      },
    },
    {
      name: "capacity",
      label: "Capacity",
      options: {
        filter: true,
        sort: false,
      },
    },
    {
      name: "today",
      label: "Today",
      options: {
        filter: true,
        sort: false,
      },
    },
    {
      name: "monthly",
      label: "Monthly",
      options: {
        filter: true,
        sort: false,
      },
    },
    {
      name: "weather",
      label: "Weather",
      options: {
        filter: true,
        sort: false,
      },
    },
    {
      name: "Status",
      label: "status",
      options: {
        filter: true,
        sort: false,
      },
    },
  ];

  return columns;
};

export const fakeData = [
  {
    panel:
      "https://media.istockphoto.com/photos/solar-panel-cell-on-dramatic-sunset-sky-backgroundclean-alternative-picture-id1310384629?b=1&k=20&m=1310384629&s=170667a&w=0&h=9qeo39JbvBKsw1ulAmn6u9l3K9CqwGHrrSzuiWVw1s8=",
    location: "Glen cove, Newyork, USA",
    capacity: "250.00 kw",
    today: "102.86 kw",
    monthly: "800.86 kw",
    weather: 34,
    status: "Working",
  },
  {
    panel:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQX6NfBXujWoooWxDU9TAQtd-6RqL4t2tTsvRnDoXpVRWzlJYJ4mQ557uE41xtDQgChz-w&usqp=CAU",
    location: "Jericho, Newyork, USA",
    capacity: "200.00 kw",
    today: "102.86 kw",
    monthly: "2302.86 kw",
    weather: 24,
    status: "Working",
  },
  {
    panel:
      "https://media.istockphoto.com/photos/solar-panel-cell-on-dramatic-sunset-sky-backgroundclean-alternative-picture-id1310384629?b=1&k=20&m=1310384629&s=170667a&w=0&h=9qeo39JbvBKsw1ulAmn6u9l3K9CqwGHrrSzuiWVw1s8=",
    location: "Wantagh, Newyork, USA",
    capacity: "75.00 kw",
    today: "0.00 kw",
    monthly: "0.00 kw",
    weather: 27,
    status: "Fault",
  },
];
