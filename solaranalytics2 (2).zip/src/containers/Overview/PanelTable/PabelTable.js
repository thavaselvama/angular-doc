import React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

import { fakeData } from "./helper";

export default function PanelTable(props) {
  return (
    <div className="table-wrapper panel-table">
      <TableContainer component={Paper}>
        <Table aria-label={props.id || "table"}>
          <TableHead>
            <TableRow>
              <TableCell width="5%">Panel</TableCell>
              <TableCell align="left" width="30%">
                Location
              </TableCell>
              <TableCell align="left">Capacity</TableCell>
              <TableCell align="left">Today</TableCell>
              <TableCell align="left">Monthly</TableCell>
              <TableCell align="left">Weather</TableCell>
              <TableCell align="left">Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {fakeData.map((row) => {
              console.log(row.weather, "row.weather");
              let rowWeatherClass = "";
              if (row.weather >= 34) {
                rowWeatherClass = "34";
              } else if (row.weather >= 27) {
                rowWeatherClass = "27";
              } else if (row.weather >= 24) {
                rowWeatherClass = "24";
              } else {
                rowWeatherClass = "27";
              }
              return (
                <TableRow
                  key={row.location}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell component="th" scope="row">
                    <div>
                      <img
                        src={row.panel}
                        className="panel-image"
                        alt={row.location + "image"}
                      />
                    </div>
                  </TableCell>
                  <TableCell>{row.location}</TableCell>
                  <TableCell>{row.capacity}</TableCell>
                  <TableCell>{row.today}</TableCell>
                  <TableCell>{row.monthly}</TableCell>
                  <TableCell>
                    <div className="weather-block">
                      <div
                        className={`icons weather-${rowWeatherClass}c`}
                      ></div>
                      <span className="value">{row.weather}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className={`${row.status.toLowerCase()}`}>
                      {row.status}
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
}
