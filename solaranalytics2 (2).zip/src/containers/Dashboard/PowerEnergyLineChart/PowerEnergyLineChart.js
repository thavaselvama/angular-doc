import React from "react";
import { Line } from "react-chartjs-2";
import ChartDataLabels from "chartjs-plugin-datalabels";
import { lineChartOptions } from "../Utils/helper";

const PowerEnergyLineChart = (props) => {
  const { data } = props;
  return (
    <div className="chart-block">
      <div className="line-bar-chart-wrapper">
        <p className="chart-title-left">Temperature (&#8451;)</p>
        <Line
          data={data}
          options={lineChartOptions}
          plugins={[ChartDataLabels]}
        />
      </div>
    </div>
  );
};

export default PowerEnergyLineChart;
