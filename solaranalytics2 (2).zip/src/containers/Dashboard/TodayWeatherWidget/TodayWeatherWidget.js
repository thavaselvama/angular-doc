import React from "react";

const TodayWeatherWidget = (props) => {
  const { data } = props;
  return (
    <div className="today-weather-widget card-wrapper-default widget">
      <p className="title">Today</p>
      <div className="icon-wrapper">
        <span className={`icons weather-${34}c-white`}></span>
      </div>
      <div className="weather-value-section">
        <span>
          24 <span className="symbol">&#176;C</span>
        </span>
        <span>
          94 <span className="symbol">&#176;F</span>
        </span>
      </div>
      <div className="weather-report-section">
        <span className="value">Precipitation: 20%</span>
        <span className="value">Humidity: 64%</span>
        <span className="value">Wind: 9 mph</span>
      </div>
    </div>
  );
};

export default TodayWeatherWidget;
