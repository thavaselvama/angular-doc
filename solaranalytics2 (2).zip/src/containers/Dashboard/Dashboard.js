import React, { useState } from "react";
import { useSelector } from "react-redux";

import { Grid, useMediaQuery } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { gridSpacing } from "../../Theme/constants/constants";

import { EnergyCard, AutoComplete } from "../../components/index";
import {
  PowerEnergyLineChart,
  TodayWeatherWidget,
  WeeklyWeatherWidget,
} from "./index";
import { fakeData } from "./Utils/helper";
import { optionList } from "../../Utils/constants";

import "./Dashboard.scss";

function Dashboard(props) {
  const theme = useTheme();
  const leftDrawerOpened = useSelector(
    (state) => state.appReducer.leftDrawerOpened
  );
  const matchUpLg = useMediaQuery(theme.breakpoints.up("lg"));

  const [powerEnergyFrequency, setPowerEnergyFrequency] = useState(
    optionList.frequency[0]
  );

  return (
    <div className="dashboard-page">
      <Grid container spacing={gridSpacing}>
        <Grid item xs={12}>
          <Grid
            container
            spacing={gridSpacing}
            sx={{ marginTop: matchUpLg ? "20px" : "" }}
          >
            {fakeData.cardData.map((item, i) => {
              return (
                <Grid item xl={3} lg={3} sm={6} xs={12} key={item.id}>
                  <EnergyCard
                    {...item}
                    itemIndex={i}
                    total={fakeData.cardData.length}
                    matchUpLg={matchUpLg}
                    leftDrawerOpened={leftDrawerOpened}
                  />
                </Grid>
              );
            })}
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <div className="card-wrapper-default environment-card-wrapper">
            <div className="card-title-header">
              <h2 className="title">Power &amp; Energy</h2>
              <div>
                <AutoComplete
                  id={"powerEnergyFrequency"}
                  options={optionList.frequency}
                  placeholder={"Select"}
                  disableClearable={true}
                  controlled={true}
                  value={powerEnergyFrequency}
                  onChange={(e, value) => setPowerEnergyFrequency(value)}
                  sx={{ width: 160 }}
                />
              </div>
            </div>
            <div className="horizontal-bar-chart-panel-energy-wrapper ">
              <PowerEnergyLineChart data={fakeData.powerEnergyLineChart} />
            </div>
          </div>
        </Grid>
        <Grid item xs={12}>
          <Grid container spacing={gridSpacing}>
            <Grid item xs={12} lg={8} xl={9}>
              <div className="widget-section-wrapper">
                <div className="today-and-weekly-widget-wrapper">
                  <TodayWeatherWidget />
                  <WeeklyWeatherWidget data={fakeData.weeklyWeatherData} />
                </div>
                <p>test1</p>
              </div>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
}

export default Dashboard;
