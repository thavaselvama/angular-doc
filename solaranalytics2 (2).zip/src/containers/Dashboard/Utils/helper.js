export const lineChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: {
    mode: "index",
    intersect: false,
  },
  plugins: {
    legend: {
      position: "bottom",
      labels: {
        usePointStyle: true,
        boxWidth: 5,
        padding: 30,
        textAlign: "center",
      },
    },
    datalabels: {
      align: "top",
      offset: 1,
    },
    title: {
      display: false,
    },
  },
  scales: {
    y: {
      type: "linear",
      display: true,
      position: "left",
    },
    x: {
      grid: {
        display: false,
      },
    },
  },
  layout: {
    padding: {
      left: 20,
    },
  },
};

export const fakeData = {
  cardData: [
    {
      title: "Energy Today",
      icon: "thunder",
      itemList: [
        {
          value: "34.75",
          suffix: "kWh",
        },
      ],
    },
    {
      title: "Energy this Month",
      icon: "thunder",
      itemList: [
        {
          value: "123.75",
          suffix: "kWh",
        },
      ],
    },
    {
      title: "Life time Energy",
      icon: "thunder",
      itemList: [
        {
          value: "234.75",
          suffix: "kWh",
        },
      ],
    },
    {
      title: "Total Income",
      icon: "dollar",
      itemList: [
        {
          value: "2434.75",
        },
      ],
    },
  ],
  // new
  powerEnergyLineChart: {
    labels: [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "July",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ],
    datasets: [
      {
        label: "Power",
        data: [
          7, 6.9, 9.5, 14.5, 18.4, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6,
        ],
        borderColor: "#7cb5ec",
        backgroundColor: "#7cb5ec",
        borderWidth: 2,
        lineTension: 0,
      },
      {
        label: "Energy",
        data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17, 16.6, 14.2, 10.3, 6.6, 4.8],
        borderColor: "#434348",
        backgroundColor: "#434348",
      },
    ],
  },

  // new
  weeklyWeatherData: [
    {
      temperature: 34,
      day: "Monday",
    },
    {
      temperature: 24,
      day: "Tuesday",
    },
    {
      temperature: 27,
      day: "Wednesday",
    },
  ],
};
