import React from "react";

const WeeklyWeatherWidget = (props) => {
  const { data } = props;
  return (
    <div className="weekly-weather-widget card-wrapper-default widget">
      {data.length > 0 &&
        data.map((el) => {
          return (
            <div className="item">
              <div className="top-content">
                <span className={`icons weather-${el.temperature}c`}></span>
              </div>
              <div className="line-bar">
                <div className="bottom-content">
                  <div className="content">
                    <div className="title">{el.day}</div>
                    <div className="value-block">
                      <span className="value">
                        24 <span className="symbol">&#176;</span>
                      </span>
                      <span className="value">
                        26 <span className="symbol">&#176;</span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
    </div>
  );
};

export default WeeklyWeatherWidget;
