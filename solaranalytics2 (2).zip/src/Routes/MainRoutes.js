import { lazy } from 'react';

import MainLayout from '../components/MainLayout/MainLayout';
import Loadable from '../components/Loadable/Loadable';

// dashboard routing
const Overview = Loadable(lazy(() => import('../containers/Overview/Overview')));
const Dashboard = Loadable(lazy(() => import('../containers/Dashboard/Dashboard')));

const MainRoutes = {
    path: '/',
    element: <MainLayout />,
    children: [
        {
            path: '/',
            element: <Overview />
        },
        {
            path: '/overview',
            element: <Overview />
        },
        {
            path: '/dashboard',
            element: <Dashboard />
        },

    ]
};

export default MainRoutes;
