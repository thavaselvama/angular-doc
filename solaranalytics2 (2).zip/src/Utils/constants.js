export const optionList = {
  frequency: [
    { label: "Last 6 Months" },
    { label: "Last 2 Months" },
    { label: "Last 2 Weeks" },
  ],
};
