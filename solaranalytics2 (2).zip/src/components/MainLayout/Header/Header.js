import React from 'react';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import {LogoSection, ProfileSection, PanelDropdown, NotificationSection } from './index';
import './Header.scss';

export default function Header (props) {

    const {matchUpMd, toggleLeftDrawerHandler} = props;
    return (
        <Toolbar className="header-wrapper">
          <Box sx={{ width : matchUpMd ? "228px" : "auto"}}>          
               <LogoSection 
                  toggleLeftDrawerHandler = {toggleLeftDrawerHandler}           
               />
          </Box>      
          <Box sx={{ display : "flex", justifyContent : "space-between", width: matchUpMd ? "calc(100% - 228px)" : "100%", alignItems: "center"}}>     
            <PanelDropdown />    
            <Box  className="right-side-section" sx={{ display : "flex", justifyContent : "space-between"}}>  
              <NotificationSection />
              <ProfileSection />
            </Box>
          </Box>                
        </Toolbar>
    )
}