import React from 'react';
import {AutoComplete} from '../../../index';

const optionList = [{label : "Panel 1"}, {label : "Panel 2"}];

const PanelDropdown = (props) => {    
    return (
        <div className="panel-dropdown-section">
            <AutoComplete
                id={"headerPanelDropdown"}
                options={optionList}
                placeholder={"Select Panel"}
                disableClearable={true}
                // controlled={true}
                // value={panelEnergyFrequency}
                // onChange={(e, value) => setPanelEnergyFrequency(value)}
                sx={{ width: 240, marginLeft: "10px" }}
            />
        </div>
    )
}

export default PanelDropdown;