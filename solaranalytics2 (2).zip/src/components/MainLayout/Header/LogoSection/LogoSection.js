import React from 'react';
import Typography from '@mui/material/Typography';
import MenuIcon from '@mui/icons-material/Menu';
import IconButton from '@mui/material/IconButton';

const LogoSection = (props) => {
    const {toggleLeftDrawerHandler} = props;
    return (
        <div className="logo-section">
            <Typography sx={{
              flexGrow : 1, 
              display: { xs: 'none', md: 'flex' }
            }} >Logo</Typography>
            <IconButton
              size="large"
              edge="start"
              color="inherit"
              aria-label="open drawer"              
              onClick={toggleLeftDrawerHandler}
              sx={{fontSize: "1.4rem"}}
            >
              <MenuIcon />
            </IconButton>  
        </div>
    )
}

export default LogoSection;