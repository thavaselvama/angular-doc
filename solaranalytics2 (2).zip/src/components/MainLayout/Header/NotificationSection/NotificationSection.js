import React, { useState } from "react";
import { IconButton, MenuList, MenuItem } from "@mui/material";
import NotificationsNoneOutlinedIcon from '@mui/icons-material/NotificationsNoneOutlined';

import { Popover } from "../../../index";

const NotificationSection = (props) => {
  const [profilePopover, setProfilePoppover] = useState({
    anchorEl: null,
    data: null,
  });

  const closePopoverHandler = () => {
    setProfilePoppover({ anchorEl: null, data: null });
  };

  const openPopoverHandler = (event) => {
    setProfilePoppover({ anchorEl: event.currentTarget, data: null });
  };

  const routeHandler = (path) => {
    closePopoverHandler();
  };

  return (
    <div className="notification-section">
      <IconButton aria-label="user-profile" className="notification-icon font-icons" onClick={openPopoverHandler}>
        <NotificationsNoneOutlinedIcon  />
      </IconButton>
      <Popover
        id={"profile-popover"}
        open={profilePopover.anchorEl ? true : false}
        anchorEl={profilePopover.anchorEl}
        handleClose={closePopoverHandler}
        anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'right',
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
      >
        <MenuList
          id="profile-menu"
          aria-labelledby="profile-button"        
        >
          <MenuItem
            onClick={() => {
              routeHandler("/myProfile");
            }}
          >
           Notification 1
          </MenuItem>
          <MenuItem
            onClick={() => {
              routeHandler("/logout");
            }}
          >
            Notification 2
          </MenuItem>
        </MenuList>
      </Popover>
    </div>
  );
};

export default NotificationSection;
