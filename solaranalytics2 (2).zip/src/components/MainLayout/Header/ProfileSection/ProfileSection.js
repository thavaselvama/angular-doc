import React, { useState } from "react";
import { IconButton, List, ListItemButton, ListItemIcon, Typography, ListItemText, Divider  } from "@mui/material";
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import PersonIcon from '@mui/icons-material/Person';
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';

import { Popover } from "../../../index";

const ProfileSection = (props) => {
  const [profilePopover, setProfilePoppover] = useState({
    anchorEl: null,
    data: null,
  });

  const closePopoverHandler = () => {
    setProfilePoppover({ anchorEl: null, data: null });
  };

  const openPopoverHandler = (event) => {
    setProfilePoppover({ anchorEl: event.currentTarget, data: null });
  };

  // const routeHandler = (path) => {
  //   closePopoverHandler();
  // };

  return (
    <div className="user-profile">
      <IconButton aria-label="user-profile" className="user-icon font-icons" onClick={openPopoverHandler}>
        <PersonIcon  />
      </IconButton>
      <Popover
        id={"profile-popover"}
        open={profilePopover.anchorEl ? true : false}
        anchorEl={profilePopover.anchorEl}
        handleClose={closePopoverHandler}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
      >
        <div className="profile-card">
          <div className="header">
            <h4 className="user-name">Shaktish kumar</h4>
            <p className="role-name">Project Admin</p>
          </div>
          <Divider />
          <div className="content">
            <List component="nav">
              <ListItemButton>
                <ListItemIcon>
                  <SettingsOutlinedIcon />
                </ListItemIcon>
                <ListItemText primary={ <Typography variant="body2">Account Settings</Typography> }/>
              </ListItemButton>              
              <ListItemButton >
                <ListItemIcon>
                  <LogoutOutlinedIcon  />
                </ListItemIcon>
                <ListItemText primary={<Typography variant="body2">Logout</Typography>} />
              </ListItemButton>
            </List>
          </div>
        </div>
      </Popover>
    </div>
  );
};

export default ProfileSection;
