import React, { useEffect } from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import { Header, SideDrawer } from "./index";
import { useDispatch, useSelector } from "react-redux";
import { toggleLeftDrawer } from "../../redux/reducer/app/appSlice";
import { styled, useTheme } from "@mui/material/styles";
import { drawerWidth } from "../../Theme/constants/constants";
import { useMediaQuery } from "@mui/material";
import { Outlet } from "react-router-dom";
import "./MainLayout.scss";

const Main = styled("main")(({ theme, open }) => {
  return {
    ...(!open && {
      borderBottomLeftRadius: 0,
      borderBottomRightRadius: 0,
      transition: theme.transitions.create("margin", {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      marginLeft: -drawerWidth,
      [theme.breakpoints.down("md")]: {
        transition: "none",
        marginLeft: 0,
      },
    }),
    ...(open && {
      transition: theme.transitions.create("margin", {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
    }),
    padding: "20px",
    width: "100%",
    marginTop: "64px",
  };
});

export default function MainLayout(props) {
  const dispatch = useDispatch();
  const theme = useTheme();
  const matchDownLg = useMediaQuery(theme.breakpoints.down("lg"));
  const matchUpMd = useMediaQuery(theme.breakpoints.up("md"));
  const leftDrawerOpened = useSelector(
    (state) => state.appReducer.leftDrawerOpened
  );

  const toggleLeftDrawerHandler = () => {
    dispatch(toggleLeftDrawer());
  };

  useEffect(() => {
    toggleLeftDrawerHandler();
  }, [matchDownLg]); // eslint-disable-line react-hooks/exhaustive-deps

  console.log(theme, "theme");
  return (
    <Box sx={{ display: "flex" }}>
      <AppBar
        enableColorOnDark
        elevation={0}
        color="inherit"
        sx={{
          bgcolor: theme.palette.background.default,
        }}
      >
        <Header
          toggleLeftDrawerHandler={toggleLeftDrawerHandler}
          matchUpMd={matchUpMd}
        />
      </AppBar>
      <SideDrawer
        matchUpMd={matchUpMd}
        leftDrawerOpened={leftDrawerOpened}
        toggleLeftDrawerHandler={toggleLeftDrawerHandler}
        drawerWidth={drawerWidth}
      />
      <Main
        className={`main-section ${
          leftDrawerOpened ? "left-drawer-opened" : ""
        }`}
        theme={theme}
        open={leftDrawerOpened}
      >
        <Outlet />
      </Main>
    </Box>
  );
}
