import * as React from "react";

import Box from "@mui/material/Box";
import { useTheme } from "@mui/material/styles";
import Typography from "@mui/material/Typography";
import { Drawer } from "@mui/material";
import MenuList from "./MenuList/MenuList";

export default function SideDrawer(props) {
  const theme = useTheme();
  const { leftDrawerOpened, drawerWidth, toggleLeftDrawerHandler, matchUpMd } =
    props;

  return (
    <Box
      component="nav"
      className="side-drawer-wrapper"
      sx={{
        display: "flex",
        // width: drawerWidthValue,
        height: leftDrawerOpened ? "100vh" : "auto",
      }}
    >
      <Drawer
        className="drawer-wrapper"
        variant={matchUpMd ? "persistent" : "temporary"}
        open={leftDrawerOpened}
        onClose={toggleLeftDrawerHandler}
        container={document.querySelector("document body")}
        anchor="left"
        sx={{
          "& .MuiDrawer-paper": {
            background: theme.palette.background.primary,
            color: theme.palette.text.primary,
            borderRight: "none",
            top: {
              sm: "0",
              md: "64px",
            },
            padding: "15px",
            width: drawerWidth,
          },
          width: drawerWidth,
        }}
        ModalProps={{ keepMounted: true }}
      >
        <>
          <Typography sx={{ display: { xs: "flex", md: "none" } }}>
            Logo
          </Typography>
          <MenuList toggleLeftDrawerHandler={toggleLeftDrawerHandler} />
        </>
      </Drawer>
    </Box>
  );
}
