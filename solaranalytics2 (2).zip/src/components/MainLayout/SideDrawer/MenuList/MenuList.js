import React, { forwardRef } from "react";
import {
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  useTheme,
  useMediaQuery
} from "@mui/material";
import { Link, useLocation } from "react-router-dom";
import AutoGraphOutlinedIcon from "@mui/icons-material/AutoGraphOutlined";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import './MenuList.css';

const menuListData = [
  {
    id: "overview",
    title: "Overview",
    url: "/overview",
    icon: <HomeOutlinedIcon />,
  },
  {
    id: "dashboard",
    title: "Dashboard",
    url: "/dashboard",
    icon: <AutoGraphOutlinedIcon />,
  },
];

export default function MenuList(props) {
  const theme = useTheme();  
  let { pathname } = useLocation();
  const {toggleLeftDrawerHandler} = props;
  const matchesSM = useMediaQuery(theme.breakpoints.down('lg'));
  const linkHandler = () => {
    if (matchesSM) {
      toggleLeftDrawerHandler();
    };
  }
  
  return (
    <List>
      {menuListData.map((item) => {
        let itemTarget = "_self";
        let selectedItem = false;
        if (item.target) { itemTarget = "_blank"; }
        
        if(item.url === "/overview" && pathname ==="/") {
          selectedItem = true 
        } else {          
          item.url === pathname ? selectedItem = true : selectedItem = false
        }
        
        return (
          <ListItemButton
            className="sideDrawer-listItemButton"
            key={item.title}
            selected={selectedItem}
            component={forwardRef((props, ref) => (
              <Link
                ref={ref}
                {...props}
                to={`${item.url}`}
                target={itemTarget}
              />
            ))}
            sx= {{                      
                borderRadius : '4px',
                marginBottom : '5px'
            }}
            onClick={linkHandler}
          >
            <ListItemIcon sx={{fontSize: "1.4rem"}}>{item.icon}</ListItemIcon>            
            <ListItemText 
              primary={<Typography  color="inherit"> {item.title} </Typography>} 
            />
          </ListItemButton>
        );
      })}
    </List>
  );
}
