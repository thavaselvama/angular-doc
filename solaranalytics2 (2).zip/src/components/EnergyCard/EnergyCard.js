import React from "react";
import { Box, Typography } from "@mui/material";
import AutoGraphIcon from "@mui/icons-material/AutoGraph";
import "./EngergyCard.scss";

const EnergyCard = (props) => {
  const {
    // content
    title,
    icon,
    itemList,
    helperText,

    // for css
    itemIndex,
    total,

    // config
    matchUpLg,
  } = props;

  let cornerUp = "";
  let firstItem = "";
  let lastItem = "";
  let leftDrawerOpened = "";

  if (matchUpLg && (itemIndex === 0 || itemIndex === total - 1)) {
    cornerUp = "corner-up";
  }
  if (itemIndex === 0) {
    firstItem = "first-item";
  }

  if (itemIndex === total - 1) {
    firstItem = "last-item";
  }

  if (leftDrawerOpened) {
    leftDrawerOpened = "left-drawer-enabled";
  }

  return (
    <Box
      component="div"
      id={`c${itemIndex + 1}`}
      className={`card-wrapper energy-card ${cornerUp} ${firstItem} ${lastItem} ${leftDrawerOpened}`}
    >
      <div className="card-header">
        <Typography className={"title"}> {title} </Typography>
      </div>
      <div className="card-content">
        {icon && (
          <div className={`icons ${icon}`}>
            <AutoGraphIcon />
          </div>
        )}
        {itemList && (
          <div className="item-list">
            {itemList.map((el) => {
              return (
                <div className="item" key={el.value}>
                  <div className={`value`}>
                    {el.value}
                    {el.suffix && (
                      <span className="value-suffix">{el.suffix}</span>
                    )}
                  </div>
                  <span className="text">{el.label}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
      {helperText && <div className="helper-text">{helperText}</div>}
    </Box>
  );
};

export default EnergyCard;
