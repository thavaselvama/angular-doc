import React from "react";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import './AutoComplete.scss';

function AutoCompleteMUI (props) {
  const {controlled} = props;

  let config = {}
  if(controlled) {
    config = { value : props.value ? props.value : undefined, onChange : props.onChange }
  }
  return (
    <Autocomplete      
      className="auto-complete-wrapper"
      disableClearable={props.disableClearable ? props.disableClearable : undefined}
      multiple={props.multiple ? props.multiple : undefined}      
      id={props.id ? props.id : undefined}
      options={props.options}    
      renderInput={(params) => <TextField {...params} label={props.label} placeholder={props.placeholder}/>}
      sx={props.sx ? props.sx : undefined}
      {...config}      
      popupIcon={<KeyboardArrowDownIcon/>}
      // open={true}
    />
  );
};

export default AutoCompleteMUI;
